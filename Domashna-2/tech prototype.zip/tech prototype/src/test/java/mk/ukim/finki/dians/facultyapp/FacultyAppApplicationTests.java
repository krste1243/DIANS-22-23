package mk.ukim.finki.dians.facultyapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FacultyAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
