package mk.ukim.finki.dians.facultyapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FacultyAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(FacultyAppApplication.class, args);
    }

}
